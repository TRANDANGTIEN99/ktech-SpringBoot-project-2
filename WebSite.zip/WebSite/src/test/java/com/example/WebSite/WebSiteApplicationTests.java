package com.example.WebSite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebSiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
